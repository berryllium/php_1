<?php
header('Content-Type: text/html; charset=utf-8');
echo 'Задание к первому уроку <a href="hw1">по ссылке</a>';
?>